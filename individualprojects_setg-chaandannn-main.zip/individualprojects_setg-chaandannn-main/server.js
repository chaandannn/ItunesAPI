// Load the modules
var express = require('express'); //Express - a web application framework that provides useful utility functions like 'http'
var app = express();
var bodyParser = require('body-parser'); // Body-parser -- a library that provides functions for parsing incoming requests
app.use(bodyParser.json());              // Support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // Support encoded bodies
const axios = require('axios');
const qs = require('query-string');
 
var pgp = require('pg-promise')();
 
var id = "";
 
const dbConfig = {
 host: 'db',
 port: 5432,
 database: 'reviews',
 user: 'postgres',
 password: 'pwd'
};
 
var db = pgp(dbConfig);
 
// Set the view engine to ejs
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/'));
 
// Home page - DON'T CHANGE
app.get('/', function(req, res) {
 res.render('pages/main', {
   my_title: "Home Page",
   items: '',
   error: false,
   message: ''
 });
});
 
app.get('/reviews', (req, res) => res.render('pages/reviews'));
app.get('/searchReview', (req, res) => res.render('pages/reviews', {message: ''})); //has the error message if no reviews to search
 
 
app.post('/search', function(req, res) {
   var song = req.body.song;
 //console.log(song)
 //console.log(req.body)
 //console.log('https://itunes.apple.com/search?term='+song)
   if(song) {
       axios({
       url: 'https://itunes.apple.com/search?term='+song,
           method: 'GET',
           dataType:'json',
       })
       .then(items => {
         //console.log(items.data.results)
           res.render('pages/main',{
             my_title: "Song Information",
             items: items,
             error: false,
             message: ''
           })
       })
       .catch(error => {
         console.log(error);
         res.render('pages/main',{
           my_title: "Song Information",
           items: '',
           error: true,
           message: error
         })
       });
 }
 else {
   res.render('pages/main',{
       my_title: "Song Information",
       items: '',
       error: true,
       message: 'There are no songs with this name'
   })
 }
});
 
 
app.post('/reviews', function(req, res) {
 var today = new Date();
 var todaysDate = today.toLocaleString(); //a way to get the current date
 var songName = req.body.song;
 var reviewSong = req.body.reviewSong;
 var insert = "INSERT INTO reviews(song review, review, reviewDate) VALUES('" + songName + "', '" + reviewSong + "', '" + todaysDate + "');";
 var select = "SELECT * from reviews;";
 
 console.log(insert);
 db.task('get-everything', task => {
         return task.batch([
             task.any(insert),task.any(select)
         ]);
     })
     .then(info => {
         //id = info[1][0].id;
         res.render('pages/reviews',{
         my_title: "Review of Songs",
         reviews:info[1],
      })
     })
     .catch(err => {
             console.log('error', err);
             res.render('pages/reviews', {
                 my_title: 'Review of Songs',
                 nameofSong: '',
                 check: '',
                 reviewDate: '',
                 message: 'The song does not exist'
             })
     });
 });
 
 app.post('/searchReview', function(req, res) {
   var songTitle = req.body.song;
   var select = "SELECT id FROM reviews WHERE nameofSong = '" + songTitle + "';";
   console.log(select); //test
 
   db.task('get-everything', task => {
           return task.batch([
             task.any(select)
           ]);
       })
       .then(info => {
           //id = info[1][0].id;
           res.render('pages/reviews',{
           my_title: "Review of Songs",
           reviews:info[0],
        })
       })
       .catch(err => {
               console.log('error', err);
               res.render('pages/reviews', {
                   my_title: 'Review of Songs',
                   nameofSong: '',
                   check: '',
                   reviewDate: '',
                   message: 'The song does not exist'
               })
       });
   });
 
 
app.listen(3000);
console.log('3000 is the magic port');